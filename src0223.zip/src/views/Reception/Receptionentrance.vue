<template>
    <div class="layoutR-main">
        <publicIframe/>

        <!--<div style="height: 600px;background-color: #ffa300;">dsa</div>-->

        <!--<button @click="refresh()">刷新</button>-->
    </div>
</template>

<script>

    export default {
        name: "Receptionentrance",

        data() {
            return {

            };
        },
        methods: {

        },
        created() {

        }

    }
</script>

<style scoped>

</style>