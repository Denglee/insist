<template>
    <div class="layoutR-main">
        <!--右边iframe-->
        <publicIframe/>

        <!--<div style="height: 600px;background-color: blue;">dsa</div>-->

    </div>
</template>

<script>
    export default {
        name: "Membercheck_card",
        data() {
            return {}
        },
        methods: {},
        created() {

        },
    }
</script>

<style lang="scss" scoped>

</style>