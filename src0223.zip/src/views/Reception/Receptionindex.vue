<template>
    <div class="layoutR-main">
        <publicIframe/>

        <!--http://192.168.0.133:20000/Admin/Reception/index/phone/18815254796.html-->
    </div>
</template>

<script>

    export default {
        name: "Receptionindex",
        data() {
            return {

            }
        },

        methods: {},
        created() {

        }
    }
</script>

<style scoped>

</style>