<template>
    <div class="error-page">
        <router-view></router-view>
    </div>
</template>