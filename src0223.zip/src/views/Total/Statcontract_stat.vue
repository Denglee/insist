<template>
    <div class="layoutR-main">
        <!--右边iframe-->
        <publicIframe/>
    </div>
</template>

<script>
    export default {
        name: "Statcontract_stat",
        data() {
            return {}
        },
        methods: {},
        created() {

        },
    }
</script>

<style lang="scss" scoped>

</style>