<template>
    <div class="layoutR-main">
        <!--右边iframe-->
        <publicIframe/>
    </div>
</template>

<script>
    export default {
        name: "Statanalyze",
        data() {
            return {}
        },
        methods: {},
        created() {

        },
    }
</script>

<style lang="scss" scoped>

</style>