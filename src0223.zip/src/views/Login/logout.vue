<template>
    <div>
        logout
    </div>
</template>

<script>
    export default {
        name: "logout",
        data() {
            return {}
        },
        methods: {},
        created() {

        },
    }
</script>

<style lang="scss" scoped>

</style>