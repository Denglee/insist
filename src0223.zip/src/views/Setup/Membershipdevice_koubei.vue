<template>
    <div>
        <div class="layoutR-main">
            <!--右边iframe-->
            <publicIframe/>

        </div>
    </div>
</template>

<script>
    export default {
        name: "Membershipdevice_koubei",
        data() {
            return {}
        },
        methods: {},
        created() {

        },
    }
</script>

<style scoped lang="scss">

</style>